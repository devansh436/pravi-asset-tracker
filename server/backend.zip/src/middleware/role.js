// middleware/role.js
// Hackathon auth: read X-Role header, look up the matching seeded user, set req.user.
// No tokens, no JWT, no Firebase. Missing/invalid role → treat as VIEWER.
import { pool } from "../db/pool.js";
import { failure } from "./response.js";

const VALID_ROLES = ["ADMIN", "INSPECTOR", "MAINTENANCE", "VIEWER"];

// In-memory cache: role → { id, email, role }
const userCache = {};

async function resolveUser(role) {
  if (userCache[role]) return userCache[role];
  const result = await pool.query(
    "SELECT id, email, role FROM users WHERE role = $1 ORDER BY id LIMIT 1",
    [role],
  );
  if (!result.rows.length) return null;
  const user = { id: result.rows[0].id, email: result.rows[0].email, role: result.rows[0].role };
  userCache[role] = user;
  return user;
}

/**
 * Reads "X-Role" header (case-insensitive). Falls back to VIEWER if missing/invalid.
 * Sets req.user = { id, email, role }.
 */
export async function attachRole(req, _res, next) {
  const raw = (req.headers["x-role"] || "").toUpperCase();
  const role = VALID_ROLES.includes(raw) ? raw : "VIEWER";
  const user = await resolveUser(role);
  // Absolute fallback: use a hard-coded viewer id so controllers never see null
  req.user = user || { id: "00000000-0000-0000-0000-000000000004", email: "viewer@example.com", role };
  return next();
}

/**
 * Route guard – use after attachRole.
 * requireRole("ADMIN", "INSPECTOR") → 403 if req.user.role not in list.
 */
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user?.role)) {
      return failure(res, 403, `Role ${req.user?.role} is not permitted for this action`);
    }
    return next();
  };
}
